#include <stdio.h>

int calculateCoefficient(int n, int k);
void printPascalTriangle(int rows);

int main() {
    int rows;

    printf("Enter the number of rows for Pascal's triangle: ");
    scanf("%d", &rows);

    printPascalTriangle(rows);

    return 0;
}

int calculateCoefficient(int n, int k) {
    if (k == 0 || k == n)
        return 1;
    else
        return calculateCoefficient(n - 1, k - 1) + calculateCoefficient(n - 1, k);
}

void printPascalTriangle(int rows) {
    for (int n = 0; n < rows; n++) {
        for (int k = 0; k <= n; k++) {
            int coefficient = calculateCoefficient(n, k);
            printf("%d ", coefficient);
        }
        printf("\n");
    }
}

